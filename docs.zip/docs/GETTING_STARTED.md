# Getting Started with AX + Claude Code

A practical guide to using AX as a virtual filesystem for Claude Code.

## What is AX?

AX gives Claude Code transparent access to multiple storage backends (local files, S3, WebDAV, SFTP, GCS, Azure) through a single FUSE mount. Claude Code's standard Read, Write, Glob, and Grep tools work against the mount point without any special configuration — it just sees a normal filesystem.

```
Claude Code (Read, Write, Glob, Grep)
        |
   FUSE Mount ~/ax-mount
        |
     AX VFS (routing + caching + sync)
        |
   FS  S3  WebDAV  SFTP  GCS  Azure  ...
```

---

## Prerequisites

**macOS:**

```bash
brew install --cask macfuse
# Allow the kernel extension in System Preferences > Privacy & Security
```

**Linux:**

```bash
# Debian/Ubuntu
sudo apt install libfuse3-dev fuse3

# Fedora
sudo dnf install fuse3-devel fuse3
```

**Build AX:**

```bash
cd ax
cargo build --workspace --release
cargo install --path crates/ax-cli
```

---

## Quick Start

### 1. Create a config file

Create `ax.yaml` in your project directory:

```yaml
name: my-project

backends:
  local:
    type: fs
    root: ./src

mounts:
  - path: /workspace
    backend: local
```

That's it. This mounts your `./src` directory at `/workspace` inside the virtual filesystem.

### 2. Mount

```bash
ax mount ~/ax-mount --config ax.yaml
```

### 3. Point Claude Code at the mount

```bash
claude --working-dir ~/ax-mount/workspace
```

Claude Code now reads and writes files through AX. All standard file operations work.

### 4. Unmount when done

```bash
ax unmount ~/ax-mount
```

---

## Adding Caching

For remote backends, caching avoids repeated network round-trips:

```yaml
name: cached-project

backends:
  local:
    type: fs
    root: ./src
  remote:
    type: s3
    bucket: my-project-bucket
    region: us-east-1

mounts:
  - path: /workspace
    backend: local

  - path: /shared
    backend: remote
    sync:
      mode: write_through

defaults:
  cache:
    enabled: true
    max_entries: 1000
    ttl_seconds: 300
```

### Sync modes

| Mode | Reads | Writes | Use case |
|------|-------|--------|----------|
| `write_through` | Cache, then backend | Write to both synchronously | Strong consistency |
| `write_back` | Cache, then backend | Write to cache, flush async | Low latency |
| `pull_mirror` | Cache, then backend | Blocked (read-only) | Remote docs |

---

## Semantic Search

AX can index your files and expose search results as a virtual `/.search/` directory.

### Index your files

```bash
# Full index
ax index /workspace --config ax.yaml

# Incremental (only changed files)
ax index /workspace --config ax.yaml --incremental

# Force full re-index
ax index /workspace --config ax.yaml --force

# Check index status
ax index-status
```

### Search from the CLI

```bash
ax search "how does authentication work" --config ax.yaml
```

### Search via FUSE

When mounted, `/.search/` is a virtual directory. Listing a query path returns symlinks to matching files:

```bash
ls ~/ax-mount/.search/query/authentication/
# 01_auth.py -> ../../workspace/src/auth.py
# 02_login.rs -> ../../workspace/src/login.rs
```

Claude Code can use Glob on this path for semantic queries.

### Watch mode with auto-indexing

```bash
ax watch --config ax.yaml
```

This watches for file changes and re-indexes them via a SQLite-backed work queue (`.ax_watch_queue.db`). The queue provides debounce, dedup, retry with exponential backoff, and crash recovery. Both dense and sparse vectors are pushed to Chroma.

---

## Multiple Backends

Mount different backends at different paths:

```yaml
name: multi-backend

backends:
  code:
    type: fs
    root: ./src
  docs:
    type: webdav
    url: https://nas.local/dav/docs
    username: user
    password: ${WEBDAV_PASS}
  data:
    type: s3
    bucket: project-data
    region: us-east-1

mounts:
  - path: /code
    backend: code

  - path: /docs
    backend: docs
    read_only: true
    sync:
      mode: pull_mirror

  - path: /data
    backend: data
    sync:
      mode: write_through
```

Environment variables are interpolated with `${VAR_NAME}` syntax.

---

## Backend Reference

### Local Filesystem

```yaml
local:
  type: fs
  root: ./data
```

### S3 / S3-compatible

```yaml
s3:
  type: s3
  bucket: my-bucket
  region: us-east-1
  prefix: project/         # optional key prefix
  endpoint: http://localhost:9000  # optional (MinIO, R2, etc.)
```

Uses the AWS default credential chain (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, or instance profile).

### WebDAV

```yaml
webdav:
  type: webdav
  url: https://server/dav
  username: user           # optional
  password: ${PASS}        # optional
```

### SFTP

```yaml
sftp:
  type: sftp
  host: server.example.com
  port: 22
  username: deploy
  private_key: ~/.ssh/id_ed25519  # or use password
  root: /var/data                  # optional remote root
```

### Google Cloud Storage

```yaml
gcs:
  type: gcs
  bucket: my-gcs-bucket
  prefix: data/                    # optional
  credentials_file: ~/gcp-creds.json  # optional
```

### Azure Blob Storage

```yaml
azure:
  type: azure_blob
  container: my-container
  account: mystorageaccount
  access_key: ${AZURE_KEY}         # optional
  prefix: data/                    # optional
```

---

## CLI Commands

### File operations

```bash
ax ls /workspace
ax cat /workspace/main.rs
ax write /workspace/notes.txt "hello"
ax append /workspace/log.txt "new line"
ax rm /workspace/tmp.txt
ax cp /workspace/a.txt /workspace/b.txt
ax mv /workspace/old.txt /workspace/new.txt
ax stat /workspace/main.rs
ax exists /workspace/main.rs
```

### Navigation

```bash
ax tree /workspace --depth 3
ax find "\.rs$" --path /workspace
ax grep "TODO" --path /workspace --recursive
```

### Management

```bash
ax config                    # show effective config
ax status                    # mounts, backends, cache stats
ax validate                  # check config for errors
ax tools --format mcp        # generate AI tool definitions
```

All commands accept `--config <path>` or look for `ax.yaml` in the current directory.

---

## Example: AI Agent Workspace

A multi-tier setup separating active context from searchable knowledge:

```yaml
name: agent-workspace

backends:
  context:
    type: fs
    root: ./data/context
  knowledge:
    type: fs
    root: ./data/knowledge
  scratch:
    type: fs
    root: ./data/scratch

mounts:
  # Hot: active working context
  - path: /context
    backend: context

  # Warm: indexed knowledge base
  - path: /knowledge
    backend: knowledge
    read_only: true

  # Temp: throwaway workspace
  - path: /scratch
    backend: scratch

defaults:
  cache:
    enabled: true
    max_entries: 500
    ttl_seconds: 600
```

```bash
# Index the knowledge base
ax index /knowledge --config ax.yaml --incremental

# Mount and start Claude Code
ax mount ~/ax-mount --config ax.yaml
claude --working-dir ~/ax-mount
```

Claude Code can read from `/context` and `/knowledge`, write to `/context` and `/scratch`, and search via `/.search/`.

---

## Troubleshooting

**macFUSE not loading (macOS):**
Open System Preferences > Privacy & Security, scroll down, and click "Allow" for the macFUSE kernel extension. Reboot.

**Permission denied on mount:**
On Linux, add your user to the `fuse` group: `sudo usermod -aG fuse $USER`, then log out and back in.

**Mount point busy on unmount:**
```bash
ax unmount ~/ax-mount --force
# or directly:
umount -f ~/ax-mount        # macOS
fusermount -uz ~/ax-mount   # Linux
```

**Config not found:**
AX searches in order: `$AX_CONFIG` env var, then `ax.yaml` in the current directory, then `~/.config/ax/config.yaml`. Pass `--config path/to/ax.yaml` explicitly.

**Stale FUSE mount after crash:**
If the AX process dies, the mount point may become stale. Force-unmount it, then re-mount:
```bash
ax unmount ~/ax-mount --force
ax mount ~/ax-mount --config ax.yaml
```
